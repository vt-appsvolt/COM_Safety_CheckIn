-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: production.cluster-cioqcs0cc6jm.us-east-1.rds.amazonaws.com    Database: checkin
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint(20) NOT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,'Chase','Beatty',NULL,NULL,1,'$2a$10$OQi42MkQO78J6KtMm9X5OeZnbAwk27zCJpNI65qRez0zEFIbsioVO','chase.b'),(10,NULL,'Nicholas','Anagnostou',NULL,NULL,1,'$2a$10$hvA7WbDCd3a7sTsU.5hXLOgPXcioUVyzZXkIL.ojh4zaAdSWW.EX2','NJAnagnostou@gmail.com'),(137,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$SIccYkdoXbheB5Mi.tK1ge6cY7Pg/UW8f691hCcTyY9V0rCSXGZpO','MCA1'),(138,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$JWBN0eulQ.3SLoh4aHPC3.vhg.9.9bKNOAvJ/4lOGySo8XoFRtGim','MCA2'),(139,NULL,'Naples ','Naples',NULL,NULL,1,'$2a$10$MQWV0Z5Cl0HgSVACTVHSsOFQTO2Ep5CmE8MVIrkcQ2fy5nmn4o9Oe','CCA'),(140,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$466yWyJKEHKEP71EENAQh.unN7L5tM48Zqk0lXDTeOfVrhydPs8k6','VME'),(141,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$iLcL8mFCe/CTON5PUINYNeDCFbTRTdBeTDmH4.gMKY4ltM3BPWw4a','BCE'),(142,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$APanwyPD6EyVQ1qAhxGdO.44h/.i9IH7y6sOXPtM2L09o0gLLVMY6','LOE'),(143,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$oBPQk8IcdMr5RkhcL9R5mexm.86zUdX71IxmzdHXXFOsZLKvyWwyu','CPE'),(144,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$TvWyjsbOeaUD./KE4srz..XAVet9y7rbHMRzg/n8Mfgwbav/DsV2G','SGE'),(145,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$9XiqDzvq/me.LGCLsWhL6.CriRo4QNcU9VGiGo7ApjPz9FAXgOSOO','FBA'),(146,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$SjEDO1y.SAKwqkXlKBcwy.ezYKgIzIwqDZq53nlwYS6MWCu/S/2u.','LPE'),(155,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$.HtLWTkQrbe04kqhFAF5tOTo9L6WD9kRhyTQgtIOpXjiFoAXk3vUy','CSN'),(274,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$.Yqp3qtXhLv7iUpD8Dp7l.3H3t2.QzTQSiu57tAyIpRLeFQRgrwXq','Pam'),(275,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$nSX7eEZkoOIHZRbXN.aZKudvFENMwiI5OBhr6iXSKViYYfq3LVopS','Allyson'),(276,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$70qc01fmgCo4w3KAOafIyuEtD0EVsg9tuKCR7b08pE9BtCIMWrWHK','Alex'),(277,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$iC2nBFzj5tkCujR43CyzQO1luN0PUUBqgKGZlTUDPyiA/q.qocGEy','Jammie'),(278,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$arROFpFc4iSgi.JSFAxDsORE8sCU3lmwj.El8QINPLqB25ZIXDVzS','Megan'),(683,NULL,'Naples','Naples',NULL,NULL,1,'$2a$10$QnuhFP6OVN1H846mqYiabe8XCqXwA32FuTaIFji7.RkL.nzmleYxm','Adam'),(33488,NULL,'OES ','Desk Manager ',NULL,NULL,1,'$2a$10$nlZM8UxWhm/1g7UfXs8HSu6p7rn.rl.BEhgnmXT/nJLqnc/e1HkC2','oesdesk'),(33489,NULL,'OES','Director',NULL,NULL,1,'$2a$10$fQb.OoPPT60CWRVtIolxnOdavVdgIwZNvrk2e1rW.56A4dHLnrYHm','OES'),(33490,NULL,'OES','Kindergarten',NULL,NULL,1,'$2a$10$70idsXF1zB3ZY2nEdCQ6u.8v97QaUclmiUzLX9NTtGbc/RAOali1m','OESK'),(33491,NULL,'OES','1st grade',NULL,NULL,1,'$2a$10$cPxIezCLYUgjpRK6fl4mrO986hSjCqfdJLv2jfh6K1lpK/AXS7pwi','OES1'),(33492,NULL,'OES','2nd grade',NULL,NULL,1,'$2a$10$0Gwk2DhQD2LrXN6o2T0aO.t0stERIBDhWw6An4ooe3PrmA0yVoHje','OES2'),(33493,NULL,'OES','3rd grade',NULL,NULL,1,'$2a$10$EAQ6P/dkhqG5lqPj1tkB2.tjPNBHb1GTLtaX2DJfIasV1HnTTBe7y','OES3'),(33494,NULL,'OES','4th grade',NULL,NULL,1,'$2a$10$qyUmpI4UCr6la6oX9qnG8.KWD2GF7UKBHl5XS8y1SaEI/ETnvPkZe','OES4'),(33495,NULL,'OES','5th grade',NULL,NULL,1,'$2a$10$vImYWHqH9QOmlI5VznDpQu23DMgpMH7DTbi9eWONNjAV5wGHjb5Yy','OES5'),(33496,NULL,'VES','Desk Manager',NULL,NULL,1,'$2a$10$6aeG75s9djIawwcIgiEAcO2.yTPmeP54bX1Qxn8a5BTdt5UHDG1xG','vesdesk'),(33497,NULL,'VES','Director',NULL,NULL,1,'$2a$10$kZ7Crx14UY4TMOdZAYcXqOmSYz9wekUdTmLXfV8HicbObRqIc8q5.','VES'),(33498,NULL,'VES','Kindergarten',NULL,NULL,1,'$2a$10$Oot.m//LqZxhLUIp00kbuOgdLPiOe4UKTyaTyflrU/zwIcprjLwsi','VESK'),(33499,NULL,'VES','1st grade',NULL,NULL,1,'$2a$10$jW0ybF.IkiaEkiHxuKv4TuCFYjngTGDLAC8RckbSov20CcYUi4m6u','VES1'),(33500,NULL,'VES','2nd grade ',NULL,NULL,1,'$2a$10$4Q.tgjkBYZ5aZ.tSxGZexu5sIlOVvqTCBQNIZxtIUX9QkMrxUOJ0i','VES2'),(33501,NULL,'VES','3rd grade',NULL,NULL,1,'$2a$10$VFaH35833wJPXmYbs/x8OemA9yiEHwpjuhHh/E4qD1iXSlWqsLxu6','VES3'),(33502,NULL,'VES','4th grade',NULL,NULL,1,'$2a$10$9XJuEBbgyddz6kt7w/0wOuV.ixRj7N2Q.EsdqnG0ichUUogApNw6S','VES4'),(33506,NULL,'VES','5th grade',NULL,NULL,1,'$2a$10$MfkNLMBbjffN58qlqUpD7uuwwzuVXVsjeQ8i/6lgB/3YXUf9AUuNG','VES5'),(33507,NULL,'PES','Desk Manager',NULL,NULL,1,'$2a$10$Y0NCOy9ChMrcaNxRKJIZQOby5iDoapZZe1GTCMRASutl7aGCIECu6','pesdesk'),(33508,NULL,'PES','Director',NULL,NULL,1,'$2a$10$JBwLzNoAu/ZFS01qIrtiZ.M/VvpsoXn2rmIFFbtgPXMsTkjSLAsIu','PES'),(33509,NULL,'PES','Kindergarten',NULL,NULL,1,'$2a$10$6bLWeEg5twXHZWIl7PJS4OP4YGNRUt2TR6FFY5GDA5xlkA6jWH/v2','PESK'),(33510,NULL,'PES','1st grade',NULL,NULL,1,'$2a$10$lj4jOpRfrxMI3Fr/PL/i8Oq3j1Nd2n/S4nfBuGvH8O1CAD.Re1U66','PES1'),(33511,NULL,'PES','2nd grade',NULL,NULL,1,'$2a$10$qSf88VKsEdfFLxrXhKEmVeowD5eIki3FCmz8IK7XaPbUQ4T6kp3I2','PES2'),(33512,NULL,'PES','3rd grade',NULL,NULL,1,'$2a$10$.lASfslT0484jlREoNyj2.RPegOVhQJyuMvDAxRi5/ND5dEjdwotq','PES3'),(33513,NULL,'PES','4th grade',NULL,NULL,1,'$2a$10$Hhwny38UjMa1XdKB3cfvze0m3aofgmqd66Ntnh71I2WScHZC/iVPm','PES4'),(33514,NULL,'PES','5th grade',NULL,NULL,1,'$2a$10$oz45xiIrUvCUSvrwJFNWeeoVeE4ndNLzxXu9MbwPTsGuHKIT95gHa','PES5'),(33515,NULL,'PME','Desk Manager',NULL,NULL,1,'$2a$10$a9aZXhY2friV8fu7PqaZcOBL689wEqB5.447nbKza2voCGBLMpIEq','pmedesk'),(33520,NULL,'PME','Kindergarten',NULL,NULL,1,'$2a$10$3xCQGs9LmqChIp7STK6sOuF1dtRHhifYprR9As/Jx88YoNqsTLYLe','PMEK'),(33521,NULL,'PME','1st grade',NULL,NULL,1,'$2a$10$BrJVF4GAE1u.CyfrX6gbfO7XQjjrc3d1NrdQ.zxldEs0nENCH9EbC','PME1'),(33522,NULL,'PME','2nd grade',NULL,NULL,1,'$2a$10$b0nF1s91DGvqDSjkfwnMTOrYfkVpwxViYhPDkFZ5lZH4Kr1WmzvBu','PME2'),(33523,NULL,'PME','3rd grade',NULL,NULL,1,'$2a$10$Sl3LJowjnSLCczBAeKW41.7ZbCZ49OQ.oJ9uDIbs1SV9lONwdX78O','PME3'),(33524,NULL,'PME','4th grade',NULL,NULL,1,'$2a$10$nsGfma2Pj4LORWJRQSE2OetvtuTvKBkZnfh5cW5/n9ah5U3IV6XUe','PME4'),(33525,NULL,'PME','5th grade',NULL,NULL,1,'$2a$10$tgoxZQDegvcwX6tLRMlFlerQkFvI6vTdu5jahWI.YOck7S3zWehae','PME5'),(33526,NULL,'EES','Desk Manager',NULL,NULL,1,'$2a$10$ebO5lQ.mBF/qtaGfQCIGru8ddhWFUOgryPAKYeo61Sv8bIz5cHHRm','eesdesk'),(33527,NULL,'EES','Director',NULL,NULL,1,'$2a$10$3CtqWiaxLDiiQMUYXBAgwOd1s5Zo22GbouOlyRYZdM4lF0ESiRyRm','EES'),(33528,NULL,'EES','Kindergarten',NULL,NULL,1,'$2a$10$SA5TdVMspA9ANGkvPmPT/edHuMtaHu3nw4PJuroVgYzXG0P/PC8Ky','EEK'),(33529,NULL,'EES','1st grade',NULL,NULL,1,'$2a$10$s2fVXdsme/V3Q.C1oMkwXep583DjxVcl8jMIABkoLJswWPqiK55Re','EES1'),(33530,NULL,'EES','2nd grade',NULL,NULL,1,'$2a$10$7PsA.XIxi5V6uDpe9Wz.N..6a1wneTgoff3xz9f9qG1QSssvY.WM.','EES2'),(33531,NULL,'EES','3rd grade',NULL,NULL,1,'$2a$10$D4eqjb/vzmM7CfS5iaBgMOkralkkUUQ97AJ8IWPnMrtP.F/bDPK3.','EES3'),(33532,NULL,'EES','4th grade',NULL,NULL,1,'$2a$10$OTOf33Mzv5iYjY0Z664o0.axZfUeNODwWDLAjL4nVE2CJtmZ8uH1i','EES4'),(33533,NULL,'EES','5th grade',NULL,NULL,1,'$2a$10$d2tPf6mNLfaLwpvapFNYfepIla8UzsOcnDtdd5w7WuYW0o2A1PRLq','EES5'),(33534,NULL,'SPE','Desk Manager',NULL,NULL,1,'$2a$10$bjXLtAvwFbQUYCtBbgkzoOa4iV0pR/jXyidmhAmsiZcFHyLcXVJwi','spedesk'),(33535,NULL,'SPE','Director',NULL,NULL,1,'$2a$10$U81r8ZVXGlRUXue8k.SpFuYt6qEIjT7FzDBhTE9Fl8r4WV5ybpJwe','SPE'),(33536,NULL,'SPE','Kingergarten',NULL,NULL,1,'$2a$10$NTp3uPpGYwFln/vzXrnkeetme4qIWa/MyAKYWif8A5TKlB1p7mXM.','SPEK'),(33537,NULL,'SPE','1st grade',NULL,NULL,1,'$2a$10$Qrzc6Ij21V6r9BOhZUALJuEfSPuQxNmayqJvp9Frle5J/Dg74JxgK','SPE1'),(33538,NULL,'SPE','2nd grade',NULL,NULL,1,'$2a$10$rjHV2UysHsj.hGIoylKmPuITR4nCtZ1Z7GAZYSJ9YJC8jUb0ww5N2','SPE2'),(33539,NULL,'SPE','3rd grade',NULL,NULL,1,'$2a$10$Oe9l0tgxFW5WbbdQOOx83uRUEOLJitkYn/GYwjgC3rOct/G7Tb.Ne','SPE3'),(33540,NULL,'SPE','4th grade',NULL,NULL,1,'$2a$10$U1MUlKJwpB9K/YkwNIknreQtcmGXk5uRMOxlN03wbLh3h72OEYd6u','SPE4'),(33541,NULL,'SPE','5th grade',NULL,NULL,1,'$2a$10$pCoGY2vqsAANvP7ggTS.Futz2dMw9coQKrhc5CleDT5URGfyR0aH6','SPE5'),(33542,NULL,'SCC','Desk Manager',NULL,NULL,1,'$2a$10$BTG7KPdjSySs6ONz9Z/NNOL3bfS9vp9hWKWacOvXuftDjpcKTN8GW','sccdesk'),(33543,NULL,'SCC','Direcor',NULL,NULL,1,'$2a$10$HYkPdwlxx8L7ymUbPlLMvuq/2zd6iB/qI4BgQp5roTDy/F7X9FRIS','SCC'),(75478,NULL,'Ron','Strong',NULL,NULL,1,'$2a$10$P4BXQ3OShyuvQ4tYLSh9uedmvM2IB3f4kie.MMGxdeJPHgNWA5j1W','rstrong'),(75503,NULL,'Sharath','Vanamala',NULL,NULL,1,'$2a$10$44ML3mPuwKPo.wVsc64uku1ZLVWxkxwG28U92VPABliMzDW1BkqES','SHARATH'),(81663,NULL,'Top','Devz',NULL,NULL,1,'$2a$10$uP/O6xdHz1TJJMOmrYe34uPjILpuV4zLaKh7xJw6HQ9amgtSbjdA6','topdevz');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-01 20:13:45
