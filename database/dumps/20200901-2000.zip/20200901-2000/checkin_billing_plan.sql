-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: production.cluster-cioqcs0cc6jm.us-east-1.rds.amazonaws.com    Database: checkin
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `billing_plan`
--

DROP TABLE IF EXISTS `billing_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `billing_plan` (
  `id` bigint(20) NOT NULL,
  `allow_early_release` bit(1) DEFAULT NULL,
  `daily_rate` decimal(19,2) DEFAULT NULL,
  `early_release` decimal(19,2) DEFAULT NULL,
  `early_release_minute_maximum` int(11) DEFAULT NULL,
  `full_day` decimal(19,2) DEFAULT NULL,
  `percentage` int(11) DEFAULT NULL,
  `plan_name` varchar(255) DEFAULT NULL,
  `allow_full_day` bit(1) DEFAULT NULL,
  `default_rate` bit(1) DEFAULT NULL,
  `full_day_minute_minimum` int(11) DEFAULT NULL,
  `program_id` bigint(20) NOT NULL,
  `weekly_rate` decimal(19,2) DEFAULT NULL,
  `specialized_billing_plan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billing_plan`
--

LOCK TABLES `billing_plan` WRITE;
/*!40000 ALTER TABLE `billing_plan` DISABLE KEYS */;
INSERT INTO `billing_plan` VALUES (18091,NULL,NULL,NULL,NULL,NULL,NULL,'Summer Weekly Rate',NULL,NULL,NULL,8,150.00,NULL),(30509,NULL,18.00,NULL,NULL,NULL,NULL,'After School Daily Regular',NULL,_binary '',NULL,6,NULL,'ColllierSchoolDistrict'),(31126,NULL,12.00,15.00,NULL,20.00,NULL,'SCC Regular After School Rate',NULL,_binary '',NULL,1,NULL,'SportsClub'),(48730,NULL,18.00,NULL,NULL,NULL,NULL,'After School Daily Regular',NULL,_binary '',NULL,2,NULL,'ColllierSchoolDistrict'),(69438,NULL,18.00,NULL,NULL,NULL,NULL,'After School Daily Regular',NULL,_binary '',NULL,7,NULL,'ColllierSchoolDistrict'),(69439,NULL,18.00,NULL,NULL,NULL,NULL,'After School Daily Regular',NULL,_binary '',NULL,5,NULL,'ColllierSchoolDistrict'),(69440,NULL,18.00,NULL,NULL,NULL,NULL,'After School Daily Regular',NULL,_binary '',NULL,3,NULL,'ColllierSchoolDistrict'),(69441,NULL,18.00,NULL,NULL,NULL,NULL,'After School Daily Regular',NULL,_binary '',NULL,4,NULL,'ColllierSchoolDistrict'),(69507,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Dunn, Aisley',NULL,NULL,NULL,3,9.90,'ScholarshipWeekly'),(69508,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Dunn, Reis',NULL,NULL,NULL,3,13.20,'ScholarshipWeekly'),(69513,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Gonzalez, Phoenix',NULL,NULL,NULL,3,8.80,'ScholarshipWeekly'),(69514,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Ochoa, Eduardo \"Eddie\"',NULL,NULL,NULL,3,6.60,'ScholarshipWeekly'),(69542,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Odne, Belle',NULL,NULL,NULL,3,11.55,'ScholarshipWeekly'),(69546,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Odne, Cam\'ron',NULL,NULL,NULL,3,15.40,'ScholarshipWeekly'),(69550,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Odne, Tiana',NULL,NULL,NULL,3,11.55,'ScholarshipWeekly'),(69557,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Stiers, Garrett',NULL,NULL,NULL,3,11.00,'ScholarshipWeekly'),(69602,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Espelucin, Mia',NULL,NULL,NULL,5,3.30,'ScholarshipWeekly'),(69603,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Espelucin, Timothy',NULL,NULL,NULL,5,4.40,'ScholarshipWeekly'),(70677,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Walts, Ayden',NULL,NULL,NULL,2,1.65,'ScholarshipWeekly'),(72995,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Auilera-Ochoa, Angeline',NULL,NULL,NULL,6,4.40,'ScholarshipWeekly'),(72997,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Earle, Alanzo',NULL,NULL,NULL,6,15.40,'ScholarshipWeekly'),(72998,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Faerber, Lilah',NULL,NULL,NULL,6,13.20,'ScholarshipWeekly'),(73001,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Taylor Serenity',NULL,NULL,NULL,4,2.20,'ScholarshipWeekly'),(73008,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Zapata, Jesus',NULL,NULL,NULL,7,24.20,'ScholarshipWeekly'),(73009,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Serrata, Danyella',NULL,NULL,NULL,7,18.15,'ScholarshipWeekly'),(73041,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Bowerman-Jone, Chase',NULL,NULL,NULL,1,2.20,'ScholarshipWeekly'),(73042,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Casasnovas, Genevieve',NULL,NULL,NULL,1,6.60,'ScholarshipWeekly'),(73043,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Casasnovas, Gianna',NULL,NULL,NULL,1,4.90,'ScholarshipWeekly'),(73044,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Navarro, Emilio',NULL,NULL,NULL,1,3.30,'ScholarshipWeekly'),(73045,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Navarro, Walter',NULL,NULL,NULL,1,3.30,'ScholarshipWeekly'),(73046,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Perry, Maurice',NULL,NULL,NULL,1,8.25,'ScholarshipWeekly'),(73047,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Russo, Aulias',NULL,NULL,NULL,1,8.25,'ScholarshipWeekly'),(73048,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Russo, Josiah',NULL,NULL,NULL,1,11.00,'ScholarshipWeekly'),(73073,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Fuller, Shea',NULL,NULL,NULL,1,2.20,'ScholarshipWeekly'),(74348,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Ariel Arthur',NULL,NULL,NULL,4,2.20,'ScholarshipWeekly'),(74975,NULL,18.00,NULL,NULL,NULL,NULL,'CCPS Teacher Rate',NULL,NULL,NULL,7,NULL,'CCPSRate'),(74976,NULL,18.00,NULL,NULL,NULL,NULL,'CCPS Teacher Rate',NULL,NULL,NULL,6,NULL,'CCPSRate'),(74977,NULL,18.00,NULL,NULL,NULL,NULL,'CCPS Teacher Rate',NULL,NULL,NULL,5,NULL,'CCPSRate'),(74978,NULL,18.00,NULL,NULL,NULL,NULL,'CCPS Teacher Rate',NULL,NULL,NULL,4,NULL,'CCPSRate'),(74979,NULL,18.00,NULL,NULL,NULL,NULL,'CCPS Teacher Rate',NULL,NULL,NULL,3,NULL,'CCPSRate'),(74980,NULL,18.00,NULL,NULL,NULL,NULL,'CCPS Teacher Rate',NULL,NULL,NULL,2,NULL,'CCPSRate'),(76675,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Colon, Arabella',NULL,NULL,NULL,4,35.20,NULL),(76694,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Brown, Larryssa',NULL,NULL,NULL,4,2.20,NULL),(76696,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Maranda-Skaggs, Jordan',NULL,NULL,NULL,4,1.65,NULL),(79435,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Grimmett, Josiah',NULL,NULL,NULL,2,2.20,NULL),(79560,NULL,NULL,NULL,NULL,NULL,NULL,'ELC- Calvert, Fiona',NULL,NULL,NULL,4,30.80,NULL),(79683,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-James, Javarris \"Prince\"',NULL,NULL,NULL,5,18.15,NULL),(81638,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Ramirez-Espinoza, Bianca',NULL,NULL,NULL,3,4.40,NULL),(81656,NULL,NULL,NULL,NULL,NULL,NULL,'ELC-Giron Gonzalez, Ivan',NULL,NULL,NULL,3,13.20,NULL);
/*!40000 ALTER TABLE `billing_plan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-01 20:13:33
