-- MySQL dump 10.13  Distrib 8.0.19, for macos10.15 (x86_64)
--
-- Host: production.cluster-cioqcs0cc6jm.us-east-1.rds.amazonaws.com    Database: checkin
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `program_employee`
--

DROP TABLE IF EXISTS `program_employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_employee` (
  `employee_id` bigint(20) NOT NULL,
  `program_id` bigint(20) NOT NULL,
  PRIMARY KEY (`employee_id`,`program_id`),
  KEY `FKcfky2hmvg1tk7qhq0a9pawtgn` (`program_id`),
  CONSTRAINT `FKcfky2hmvg1tk7qhq0a9pawtgn` FOREIGN KEY (`program_id`) REFERENCES `after_school_program` (`program_id`),
  CONSTRAINT `FKr7tib7gwlfbvr7mf9deml5mpl` FOREIGN KEY (`employee_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_employee`
--

LOCK TABLES `program_employee` WRITE;
/*!40000 ALTER TABLE `program_employee` DISABLE KEYS */;
INSERT INTO `program_employee` VALUES (1,1),(10,1),(137,1),(138,1),(139,1),(140,1),(141,1),(142,1),(143,1),(144,1),(145,1),(146,1),(155,1),(274,1),(275,1),(276,1),(277,1),(278,1),(683,1),(33542,1),(33543,1),(75478,1),(75503,1),(81663,1),(1,2),(10,2),(275,2),(277,2),(33515,2),(33520,2),(33521,2),(33522,2),(33523,2),(33524,2),(33525,2),(75478,2),(75503,2),(81663,2),(1,3),(10,3),(275,3),(277,3),(33507,3),(33508,3),(33509,3),(33510,3),(33511,3),(33512,3),(33513,3),(33514,3),(75478,3),(75503,3),(81663,3),(1,4),(10,4),(275,4),(277,4),(33534,4),(33535,4),(33536,4),(33537,4),(33538,4),(33539,4),(33540,4),(33541,4),(75478,4),(75503,4),(81663,4),(1,5),(10,5),(275,5),(277,5),(33526,5),(33527,5),(33528,5),(33529,5),(33530,5),(33531,5),(33532,5),(33533,5),(75478,5),(75503,5),(81663,5),(1,6),(10,6),(275,6),(277,6),(33488,6),(33489,6),(33490,6),(33491,6),(33492,6),(33493,6),(33494,6),(33495,6),(75478,6),(75503,6),(81663,6),(1,7),(10,7),(275,7),(277,7),(33496,7),(33497,7),(33498,7),(33499,7),(33500,7),(33501,7),(33502,7),(33506,7),(75478,7),(75503,7),(81663,7),(1,8),(10,8),(137,8),(138,8),(139,8),(140,8),(141,8),(142,8),(143,8),(144,8),(145,8),(146,8),(155,8),(274,8),(275,8),(276,8),(277,8),(278,8),(683,8),(75478,8),(75503,8);
/*!40000 ALTER TABLE `program_employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-01 20:13:11
